#!/bin/sh

systemctl disable check_lte.service
systemctl stop check_lte.service
rm /etc/systemd/system/check_lte.service

exit 0 
