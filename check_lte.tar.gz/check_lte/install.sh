#!/bin/sh

cp check_lte.service /etc/systemd/system/check_lte.service
chmod 644 /etc/systemd/system/check_lte.service
systemctl daemon-reload
systemctl enable check_lte.service
systemctl start check_lte.service

exit 0
