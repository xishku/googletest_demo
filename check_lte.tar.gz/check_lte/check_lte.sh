#!/bin/sh

function ping_gateway()
{
    ping -c 1 -w 100 223.5.5.5 > /dev/null
                                  
    if [[ $? != 0 ]];then     
        return -1      
    else                   
		return 0
    fi
}

function check_connect()
{
	for i in {1..60};
	do
		echo ${i}

		ping_gateway
		if [ $? = 0 ]; then
			echo "ping ok ..."
			return 0
		fi

		sleep 5s
	done

	return -1
}

while true
do
	check_connect

	if [ $? = 0 ]; then
		echo "ping ok ..."
	else
        echo "All pings fail within 5 minutes. Reset LTE module now..."

		gpioset 0 9=0
		gpioset 0 9=1
		echo "Reset LTE module finish."
	fi
        
	sleep 5s                                          
done 

exit 0
